import type { ReactNode } from 'react';
import type { PlayerColor } from '../theme/tokens';
import { formatPoints, formatRank } from '../format';
import { Avatar } from './Avatar';
import { cx } from './cx';

export type RankingEntry = {
  id: string;
  position: number;
  name: string;
  color: PlayerColor;
  hexagons: number;
  points: number;
  isMe?: boolean;
};

export function RankingRow({ entry, sticky }: { entry: RankingEntry; sticky?: boolean }) {
  return (
    <li
      className={cx('hx-rank-row', entry.isMe && 'hx-rank-row--me', sticky && 'hx-rank-row--sticky')}
      aria-current={entry.isMe ? 'true' : undefined}
    >
      <span className="hx-rank-row__pos">{formatRank(entry.position)}</span>
      <Avatar name={entry.name} color={entry.isMe ? 'me' : entry.color} />
      <span className="hx-rank-row__name">{entry.isMe ? 'Vos' : entry.name}</span>
      <span className="hx-rank-row__hex">{entry.hexagons} hx</span>
      <span className="hx-rank-row__pts">{formatPoints(entry.points)}</span>
    </li>
  );
}

export function RankingList({ entries, label = 'Ranking' }: { entries: RankingEntry[]; label?: string }): ReactNode {
  return (
    <ol className="hx-ranking" aria-label={label}>
      {entries.map((e) => (
        <RankingRow key={e.id} entry={e} />
      ))}
    </ol>
  );
}
